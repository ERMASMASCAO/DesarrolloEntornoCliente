$('.slider').bxSlider({
    autoControls: true,
    auto: true,
    pager: true,
    slideWidth: 800,
    mode: 'fade',
    captions: true,
    speed: 1000
});