function grande(element) {
    element.style.fontSize = '16pt';

}
function pequeno(element) {
   element.style.fontSize = '12pt';

}
