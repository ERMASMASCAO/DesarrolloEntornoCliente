$(document).ready(function(){
    alert( "Size: " + $( "div" ).length );
    $("div").css('color','green');
});

