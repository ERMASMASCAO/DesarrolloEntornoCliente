$(document).ready(function(){
    $("#img").fadeOut(1000, function(){
        $("#img").slideDown(3000);
        $("#img").slideUp(1000);
    });
})