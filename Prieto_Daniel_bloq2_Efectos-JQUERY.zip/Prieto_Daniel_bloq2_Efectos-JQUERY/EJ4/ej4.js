$(document).ready(function() {
    $("h1").click(function() {
      $("h1").animate({
        "background-color": "yellow"
        }, 1000);
    });
});
  